const {dbConnect} = require('./config/db');
require('dotenv').config();

// DB
dbConnect().catch((err) => console.log(err));

// Classes
const Error = require('./model/Error');

exports.handler = async (event, context, callback) => {
    const {payload: {type, message}} = event.getParameters();
    if(!type || !message){
       return 'All fields required'
    }

    let error = await Error.create({type, message});

    if(error){
        return error
    } else {
        return 'Unsuccessful'
    }
}